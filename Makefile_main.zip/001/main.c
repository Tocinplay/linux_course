#include "main.h"
void main()
{
    show_purpose();
}
