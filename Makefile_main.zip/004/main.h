#ifndef __MAIN_H__
#define __MAIN_H__

#include <stdio.h>

void show_purpose()
{
    printf("i wish you become better\n");
}

#endif