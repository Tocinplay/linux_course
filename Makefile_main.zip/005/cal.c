#include "cal.h"
void do_add(int a,int b)
{
    printf("result is %d + %d = %d\n",a,b,a+b);
}