#ifndef __CAL_H__
#define __CAL_H__

#include <stdio.h>

void do_add(int a,int b);

#endif