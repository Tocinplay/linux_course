#include "main.h"
#include "cal.h"
void main()
{
    show_purpose();
    do_add(1,1);
}
